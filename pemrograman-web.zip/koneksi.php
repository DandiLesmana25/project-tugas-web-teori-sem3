<?php
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'pweb';

$con = mysqli_connect ($host, $username, $password, $db_name);
?>