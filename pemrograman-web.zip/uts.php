<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/CSS/main.css">
    <title>UTS | PEMROGRAMAN WEB</title>
</head>
<body>
    <section class="coba">
        <h2>UTS Pemgrograman Web 2022/2023 </h2>
        <table>
        <form action="hasil.php" method="POST">
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" name=nama></td>
            </tr>
            <tr>
                <td>NIM</td>
                <td>:</td>
                <td><input type="number" name=nim></td>
            </tr>
            <tr>
                <td>Presensi</td>
                <td>:</td>
                <td><input type="number" name=presensi></td>
            </tr>
            <tr>
                <td>Tugas</td>
                <td>:</td>
                <td><input type="number" name=tugas></td>
            </tr>
            <tr>
                <td>UTS</td>
                <td>:</td>
                <td><input type="number" name=uts></td>
            </tr>
            <tr>
                <td>UAS</td>
                <td>:</td>
                <td><input type="number" name=uas></td>
            </tr>
            <tr>
                <td>
                <input type="submit" name="proses" value="Proses">
                </td>
            </tr>
        </form>
        </table>
    </section>
</div>
</body>
</html>